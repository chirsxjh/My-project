from distutils.core import setup

setup(
    name='awd',
    version='1.0',
    description='sdk for di input , output and param',
    author='sam',
    author_email='1131360171@qq.com',
    url='',
    license='No License',
    platforms='python 2.7',
    py_modules=['aiword.mnist7']
    #package_dir={'': 'aiword'},
    #packages=['lib', 'common.http']
)


